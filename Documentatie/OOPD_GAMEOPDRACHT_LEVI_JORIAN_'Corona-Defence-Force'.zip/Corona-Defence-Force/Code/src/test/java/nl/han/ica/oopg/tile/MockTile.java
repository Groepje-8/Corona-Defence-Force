package nl.han.ica.oopg.tile;

import nl.han.ica.oopg.objects.Sprite;

public class MockTile extends Tile{
    /**
     * @param sprite
     */
    public MockTile(Sprite sprite) {
        super(sprite);
    }
}
