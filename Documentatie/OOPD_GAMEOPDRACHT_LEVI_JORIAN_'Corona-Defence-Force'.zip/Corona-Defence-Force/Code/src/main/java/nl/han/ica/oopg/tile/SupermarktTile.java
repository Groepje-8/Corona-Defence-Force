package nl.han.ica.oopg.tile;

import nl.han.ica.oopg.objects.Sprite;

public class SupermarktTile extends Tile {

	public SupermarktTile(Sprite sprite) {
		super(sprite);
	}

}
