package nl.han.ica.oopg.tile;

import nl.han.ica.oopg.objects.Sprite;

public class GrasTile extends Tile {
	//private Verdediger verdediger;
	
	public GrasTile(Sprite sprite) {
		super(sprite);
	}
}
