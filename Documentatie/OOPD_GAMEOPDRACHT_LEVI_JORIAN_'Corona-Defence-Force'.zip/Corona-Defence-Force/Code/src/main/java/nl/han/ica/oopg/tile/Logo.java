package nl.han.ica.oopg.tile;

import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public class Logo extends SpriteObject {

	public Logo(Sprite sprite) {
		super(sprite);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
