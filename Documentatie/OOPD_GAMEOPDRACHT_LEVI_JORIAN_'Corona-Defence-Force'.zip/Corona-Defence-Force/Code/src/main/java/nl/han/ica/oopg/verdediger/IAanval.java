package nl.han.ica.oopg.verdediger;




public interface IAanval {

	public int schieten();

	
}
