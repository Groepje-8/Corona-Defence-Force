# Corona-Defence-Force
De OOPD eindopdracht OOPG a.k.a. 'De Gameopdracht'  
Gemaakt door Jorian en Levi.  
Maakt gebruik van de Game Engine geleverd door de HAN.  
Spelen op eigen risico.


# Trello
[Trello locatie](https://trello.com/b/FPOyRvxq/oopd-gameopdracht-corona-defence-force)


# Handige Links
1. [OOPG Github](https://github.com/HANICA/oopg)
1. [OOPG Wiki](https://github.com/HANICA/oopg/wiki)
1. [OOPG API](https://hanica.github.io/oopg/)
1. [OOPG Waterworld voorbeeld](https://github.com/HANICA/waterworld)
1. [Tower Defence voorbeeld 1](https://github.com/callumdmay/java-tower-defense)
1. [Tower Defence voorbeeld 2](https://github.com/Leopard501/Crazy-Critters-Attack)
1. [TileMapEditor](https://www.mapeditor.org/)
